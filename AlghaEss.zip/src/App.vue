<template>
  <div id="app">
    <router-view/>
  </div>
</template> 
<script  type="text/javascript"  src="http://maps.googleapis.com/maps/api/js?v=3&key=AIzaSyBPMDpoB5OQJ0vCXir5O304WqGizkieuRw&callback=initialize">
</script> 
<script>
export default {
  name: 'App'
}
</script>
